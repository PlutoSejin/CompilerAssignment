int main(char c, int d) {
    int a;
    INT b;
    char c;
    int d = 3;
    IF (a == -1){
         c="a";
    }
    else if (a != 45){
        b= -3;
    }
    else if(a <= 734){
        b= b-3;
    }
    else if(a >= 457){
        CHAR if023 = "hello world";
    }
    else if(a < -245){
        a= a+-1;
    }
    else if(a > -3421445){
       a = a-1;
    }
    else if(a!=-500){
        c=" "
    }
    ELSE{
       while(a!=2){
        a= a--2;
       }
    }
    WHILE(a/32==2){
       a= a*2;
    }
    int 0abc0;
    int 123if;
    int 123if0;
    k=123if0
    int j=2;
    j--23
    return -0;
}