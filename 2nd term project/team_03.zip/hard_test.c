int main(char c, int d) {
    int a;
    INT b;
    char c;
    int d; 
    d=3;
    c="abc";
    b=-1;
    a=0;
    IF (a == -1){
         c="a";
    }
    ELSE{
       while(a!=2){
        a= a--2;
       }
    }
    WHILE(a == b){
       a= a*2;
    }
    int j;
    j = j--23;
    return 0;
}